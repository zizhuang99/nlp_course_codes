#!/usr/bin/env python
import sys

from lexsub_xml import read_lexsub_xml

# suggested imports 
from nltk.corpus import wordnet as wn
from nltk.corpus import stopwords
import gensim
import numpy as np
import string

# Participate in the 4705 lexical substitution competition (optional): NO
# Alias: [please invent some name]
stop_words=stopwords.words('english')
def tokenize(s):
    s = "".join(" " if x in string.punctuation else x for x in s.lower())    
    return s.split() 

def get_candidates(lemma, pos):
    # Part 1
    possible_synonyms = []
    l1=wn.lemmas(lemma, pos=pos)

    for i in range(len(l1)):
        s1=l1[i].synset().lemmas()
        possible_synonyms.extend([j.name().replace('_',' ') for j in s1])
           
    try:
        ans=set(possible_synonyms)
        ans.remove(lemma)
        return ans
    except:
        return 'no candidate'

def smurf_predictor(context):
    """
    Just suggest 'smurf' as a substitute for all words.
    """
    return 'smurf'

def wn_frequency_predictor(context):

    l1=wn.lemmas(context.lemma, pos=context.pos)
    temp={}
    for i in range(len(l1)):
        s1=l1[i].synset().lemmas()
        for j in s1:
            temp[j.name()]=temp.get(j.name(),0)+j.count()
      
    del temp[context.lemma]

    return max(temp, key=lambda k: temp[k])

def remove_stopwords(item):
    # stop_words=stopwords.words('english')
    for word in item:
        if word in stop_words:
            item.remove(word)
    return item

def wn_simple_lesk_predictor(context):
    sentence=context.left_context
    sentence.extend(context.word_form)
    sentence.extend(context.right_context)
    
    
    sentence=tokenize(' '.join(remove_stopwords(sentence)))
    dict_={}
    l1=wn.lemmas(context.lemma, pos=context.pos)
    temp_number=[]
    candidate_dict={}
    
    for i in range(len(l1)):
        for item in sentence:
            dict_[item]=0
        s1=l1[i].synset()
        
        definition_=tokenize(' '.join(remove_stopwords(s1.definition().split())))
        list_=definition_
        examples=s1.examples()
        for item in examples:
            list_.extend(tokenize(' '.join(remove_stopwords(item.split()))))
        hypernyms=s1.hypernyms()
        for sysnset_hyper in hypernyms:
            definition_=tokenize(' '.join(remove_stopwords(sysnset_hyper.definition().split())))
            list_.extend(definition_)
            examples=sysnset_hyper.examples()
            for item in examples:
                list_.extend(tokenize(' '.join(remove_stopwords(item.split()))))
        set_=set(list_)   
        temp_number.append(len(set_))
    ans=context.lemma
    if max(temp_number)!=0:

        index=np.argmax(temp_number)
        
        for j in l1[index].synset().lemmas():
            candidate_dict[j.name()]=candidate_dict.get(j.name(),0)+j.count()
        del candidate_dict[context.lemma]
        try:
            ans=max(candidate_dict, key=lambda k: candidate_dict[k])
        except:
            ans=ans  
     #replace for part 3        

    
    while ans == context.lemma:
        index_syn=np.argmax([j.count() for j in l1])
        most_freq_syn=l1[index_syn].synset()
        selectindex=np.argmax([j.count() if j.name() not in context.lemma else 0 for j in most_freq_syn.lemmas()])
        ans=most_freq_syn.lemmas()[selectindex]
        l1.pop(index_syn)
        ans=ans.name()
    return ans
   

class Word2VecSubst(object):
        
    def __init__(self, filename):
        self.model = gensim.models.KeyedVectors.load_word2vec_format(filename, binary=True)    
        
    def predict_nearest(self,context):
        possible_synonyms = []
        l1=wn.lemmas(context.lemma, pos=context.pos)

        for i in range(len(l1)):
            s1=l1[i].synset().lemmas()
            for j in s1:
                temp_name=j.name()
                if '_' in temp_name:
                    possible_synonyms.extend(temp_name.replace('_',' ').split())
                else:
                    possible_synonyms.append(temp_name)
        ans=set(possible_synonyms)
        ans.remove(context.lemma)
        
        candidate=list(ans)
        candidate_w2v=0
        candidate_item=candidate[0]
        for item in candidate:
            try:
                if candidate_w2v<self.model.similarity(context.lemma,item):
                    candidate_w2v=self.model.similarity(context.lemma,item)
                    candidate_item=item
            except:
                continue       
        return candidate_item
          # replace for part 4
    def cos(self,v1,v2):
        return np.dot(v1,v2)/(np.linalg.norm(v1)*np.linalg.norm(v2))
    def predict_nearest_with_context(self, context): 

        if len(tokenize(' '.join(remove_stopwords(context.left_context))))>5:
            sentence=tokenize(' '.join(remove_stopwords(context.left_context)))[-5:]
        else:
            sentence=tokenize(' '.join(remove_stopwords(context.left_context)))
        sentence.append(context.lemma)
        if len(tokenize(' '.join(remove_stopwords(context.right_context))))>5:
            sentence.extend(tokenize(' '.join(remove_stopwords(context.right_context)))[:5])
        else:
            sentence.extend(tokenize(' '.join(remove_stopwords(context.right_context))))
        

        single_v=np.zeros(300)
        print(sentence)

        for w in sentence:
            try:
                single_v+=self.model[w]
            except:
                continue

        possible_synonyms = []
        l1=wn.lemmas(context.lemma, pos=context.pos)


        for i in range(len(l1)):
            s1=l1[i].synset().lemmas()
            for j in s1:
                temp_name=j.name()
                if '_' in temp_name:
                    possible_synonyms.append(temp_name.replace('_',' '))
                else:
                    possible_synonyms.append(temp_name)
        ans=set(possible_synonyms)
        ans.remove(context.lemma)

        candidate=list(ans)
        candidate_w2v=0
        candidate_item=''
        for item in candidate:
            try:
                if candidate_w2v<self.cos(single_v,self.model[item]):
                    candidate_w2v=self.cos(single_v,self.model[item])
                    candidate_item=item
            except:
                continue       
        return candidate_item # replace for part 5

if __name__=="__main__":

    # At submission time, this program should run your best predictor (part 6).

    W2VMODEL_FILENAME = 'GoogleNews-vectors-negative300.bin.gz'
    predictor = Word2VecSubst(W2VMODEL_FILENAME)

    for context in read_lexsub_xml(sys.argv[1]):
        print(context)  # useful for debugging
        # prediction = smurf_predictor(context) 
        # prediction = wn_frequency_predictor(context) 
        # prediction = wn_simple_lesk_predictor(context) 
        # prediction = predictor.predict_nearest(context)
        prediction = predictor.predict_nearest_with_context(context)
        print("{}.{} {} :: {}".format(context.lemma, context.pos, context.cid, prediction))
